m=450;
n=434;

testphis=load('testphis');
for i=1:n
    for j=1:m
        ii=floor(((i-1)*m+j-1)/3)+1;
        jj=(i-1)*m+j-3*(floor(((i-1)*m+j-1)/3));
        phi1(i,j)=testphis(ii,jj);
    end
end

contourf(R,Z,phi1,100)
axis equal;
