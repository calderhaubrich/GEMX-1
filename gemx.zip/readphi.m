clear;
close all;
phirphi=load('testphi_r_phi');
R=load('R.dat');
Z=load('Z.dat');
Bt=load('Bt.dat');
BR=load('BR.dat');
BZ=load('Bz.dat');
mask2=load('mask2');
mask3=load('mask3');
testphi=load('testphi');
testphis=load('testphis');
masktest=load('debug.dat');
psitest=load('psi_test');
netest=load('testne0');
apar0=load('testapar0');
ne1=load('testnes');
ne2=load('testne');
apar1=load('testapars');
apar2=load('testapar');
jpar1=load('testjpars');
jpar2=load('testjpar');
%mask=load('debug.dat');

p=0:2*pi/33:2*pi*(1-1/33);
%phi=zeros(434,450);
for i=1:434
    for j=1:450
        ii=floor(((i-1)*450+j-1)/3)+1;
        jj=(i-1)*450+j-3*(floor(((i-1)*450+j-1)/3));
        phi1(i,j)=testphis(ii,jj);
        phi2(i,j)=testphi(ii,jj);
        a0(i,j)=apar0(ii,jj);
        mask(i,j)=masktest(ii,jj);
        psi(i,j)=psitest(ii,jj);
        ne(i,j)=netest(ii,jj);
        n1(i,j)=ne1(ii,jj);
        n2(i,j)=ne2(ii,jj);
        a1(i,j)=apar1(ii,jj);
        a2(i,j)=apar2(ii,jj);
        j1(i,j)=jpar1(ii,jj);
        j2(i,j)=jpar2(ii,jj);
        m2(i,j)=mask2(ii,jj);
        m3(i,j)=mask3(ii,jj);
    end
end

for i=1:33
    for j=1:450
        ii=floor(((i-1)*450+j-1)/3)+1;
        jj=(i-1)*450+j-3*(floor(((i-1)*450+j-1)/3));
        prphi(i,j)=phirphi(ii,jj);
    end
end

figure
[c,h]=contourf(R,Z,n1,100);
axis equal
set(h,'LineColor','none')
title('ne1')

figure
[c,h]=contourf(R,Z,n2,100);
axis equal
set(h,'LineColor','none')
title('ne2')


figure
[c,h]=contourf(R,Z,a1,100);
axis equal
set(h,'LineColor','none')
title('Apar1')

figure
[c,h]=contourf(R,Z,a2,100);
axis equal
set(h,'LineColor','none')
title('Apar2')

figure
[c,h]=contourf(R,Z,j1,100);
axis equal
set(h,'LineColor','none')
title('jpar1')

figure
[c,h]=contourf(R,Z,j2,100);
axis equal
set(h,'LineColor','none')
title('jpar2')

figure
[c,h]=contourf(R,Z,ne,100);
axis equal
set(h,'LineColor','none')
title('ne0')

figure
[c,h]=contourf(R,Z,a0,100);
axis equal
set(h,'LineColor','none')
title('Apar0')

figure
[C,h]=contourf(R,Z,phi1,100);
set(h,'LineColor','none')
hold on
title('phi1')
axis equal

figure
[C,h]=contourf(R,Z,phi2,100);
set(h,'LineColor','none')
hold on
title('phi2')
%contour(R,Z,mask);
%contour(R,Z,psi);
axis equal

valuea=(mask-1).*a2;
valuej=(m2-2).*j2;
valuen=(m3-3).*n2;
valuephi=(mask-1).*phi2;
