module restore
module load nvhpc
module load cray-fftw
export LD_LIBRARY_PATH=/global/cfs/cdirs/mp118/software/petsc/install/lib:$LD_LIBRARY_PATH
